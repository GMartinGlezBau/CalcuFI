//
//  ConvertmcmViewController.swift
//  convert
//
//  Created by Rodrigo Ocaña on 29/11/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class ConvertmcmViewController: UIViewController {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBOutlet weak var mcm: UITextField!
    
    @IBOutlet weak var resultado: UILabel!
    
    @IBOutlet weak var mmm: UITextField!
    
    @IBOutlet weak var resultado2: UILabel!
    
    @IBOutlet weak var pulg: UITextField!
    
    @IBOutlet weak var resultado3: UILabel!
    
    @IBOutlet weak var pi: UITextField!
    
    @IBOutlet weak var resultado4: UILabel!
    
    @IBOutlet weak var km: UITextField!
    
    @IBOutlet weak var resultado5: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    
    @IBAction func convertmcm(_ sender: UIButton) {
        var cm = Double(mcm.text!)
        cm = Double(mcm.text!)
        if( cm != nil){
        var total = cm!/100
        total = Double(cm!/100)
        print(total)
            resultado.text! = String("\(total) m")
        }
        else{
            resultado.text = String("Ingrese Valores numericos")
        }
    }
    
    @IBAction func conmam(_ sender: UIButton) {
        var mm = Double(mmm.text!)
        mm = Double(mmm.text!)
        if( mm != nil){
        var total2 = mm!/1000
        total2 = Double(mm!/1000)
        print(total2)
        resultado2.text! = String("\(total2) m")
        }
        else{
            resultado2.text = String("Ingrese Valores Numericos")
        
        }
        }
    
    @IBAction func pulgm(_ sender: UIButton) {
        var p = Double(pulg.text!)
        p = Double(pulg.text!)
        if( p != nil){
        var total3 = p! * 0.0254
        total3 = Double(p! * 0.0254)
        print(total3)
        resultado3.text! = String("\(total3) m")
        }
        else{
            resultado3.text = String("Ingrese Valores Numericos")
        }
        }
    
    @IBAction func piam(_ sender: UIButton) {
        var i = Double(pi.text!)
        i = Double(pi.text!)
        if( i != nil){
        var total4 = i! * 0.9144
        total4 = Double(i! * 0.9144)
        print(total4)
        resultado4.text! = String("\(total4) m")
        }
        else{
            resultado4.text = String("Ingrese Valores Numericos")
        }
        }
    
    @IBAction func kmam(_ sender: UIButton) {
        var k = Double(km.text!)
        k = Double(km.text!)
        if( k != nil){
        var total5 = k! * 1000
        total5 = Double(k! * 1000 )
        print(total5)
        resultado5.text! = String("\(total5) m")
        }
        else{
            resultado5.text = String("Ingrese Valores Numericos")
        }
        }
    
    
}
