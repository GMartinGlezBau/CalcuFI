//
//  teotarmruViewController.swift
//  convert
//
//  Created by Guest User on 12/5/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class teotarmruViewController: UIViewController {

    @IBOutlet weak var imagenes: UIImageView!
    
    var imagene = [String]()
    var indice = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        imagene.append("im1")
        imagene.append("im2")
        imagene.append("im3")
        imagene.append("im4")
    }
    @IBAction func nextimage(_ sender: UIButton) {
        
        imagenes.image = UIImage(named:imagene[indice])
        if indice == 3 {
            indice = 1
        }else {
            indice = indice + 1
            
        }
        
}
}
