//
//  CconvertViewController.swift
//  convert
//
//  Created by Rodrigo Ocaña on 29/11/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class CconvertViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    @IBAction func fromdistaView(segue:UIStoryboardSegue!){}
    @IBAction func fromtiemView(segue:UIStoryboardSegue!){}
    @IBAction func fromvelocidadView(segue:UIStoryboardSegue!){}
}
