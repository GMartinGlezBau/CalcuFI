//
//  instructivoViewController.swift
//  Fisica
//
//  Created by Usuario invitado on 12/6/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class instructivoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
