//
//  CvoltajeViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/26/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class CvoltajeViewController: UIViewController {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    
    @IBOutlet weak var Intensidad: UITextField!
    
    
    @IBOutlet weak var Resistencia: UITextField!
    
    
    @IBOutlet weak var Resultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func voltaje(_ sender: UIButton) {
       
        
        var i = Double(Intensidad.text!)
        i = Double(Intensidad.text!)
       
        var r = Double(Resistencia.text!)
        r = Double(Resistencia.text!)
        if(r != nil && i != nil){
            var modal = i!*r!
            modal = Double(i!*r!)
            print(modal)
            Resultado.text! = String("El Voltaje es:\(modal) [V]")
            
        }
        else {Resultado.text = String("Ingrese Valores Numericos")
        
        }
    }
    
}
