//
//  CresistenciaViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/26/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit


class CresistenciaViewController: UIViewController {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    @IBOutlet weak var voltaje: UITextField!
    
    @IBOutlet weak var intensidad: UITextField!
    
    
    @IBOutlet weak var resultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func resistencia(_ sender: UIButton) {
        
    var v = Double(voltaje.text!)
        v = Double(voltaje.text!)
    var i = Double(intensidad.text!)
        i = Double(intensidad.text!)
        if(v != nil && i != nil) {
            var total = v!/i!
            total = Double(v!/i!)
            print(total)
            resultado.text! = String("La Resistencia es:\(total) [Ω]")
            }
        else {
        resultado.text = String("Ingrese Valores Numericos")
   
    }
}
}
