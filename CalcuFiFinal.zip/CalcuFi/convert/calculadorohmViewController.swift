//
//  calculadorohmViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/12/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class calculadorohmViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func voltaje(_ sender: UIButton) {
    }
    
    @IBAction func intensidad(_ sender: UIButton) {
    }
    
    @IBAction func resistencia(_ sender: UIButton) {
    }
    
    @IBAction func fromCresistenciaView(segue:UIStoryboardSegue!){}
    @IBAction func fromCintensidaView(segue:UIStoryboardSegue!){}
    @IBAction func fromCvoltajeView(segue:UIStoryboardSegue!){}
    
    
    
    
}
