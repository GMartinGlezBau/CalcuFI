//
//  TiempoViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/29/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class TiempoViewController: UIViewController {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    
    @IBOutlet weak var min: UITextField!
    @IBOutlet weak var resultado: UILabel!
    
    @IBOutlet weak var hrs: UITextField!
    @IBOutlet weak var resultado2: UILabel!
    
    @IBOutlet weak var Dias: UITextField!
    @IBOutlet weak var resultado3: UILabel!
    
    @IBOutlet weak var Sem: UITextField!
    @IBOutlet weak var resultado4: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func mins(_ sender: UIButton) {
        var m = Double(min.text!)
        m = Double(min.text!)
        if( m != nil){
        var total = m! * 60
        total = Double(m! * 60)
        print(total)
        resultado.text! = String("\(total) seg.")
        }
        else {
            resultado.text = String("Ingrese Valores Numericos")
        }
        }
    
    @IBAction func hrsaseg(_ sender: UIButton) {
        var h = Double(hrs.text!)
        h = Double(hrs.text!)
        if( h != nil){
        var total2 = h! * 3600
        total2 = Double(h! * 3600)
        print(total2)
        resultado2.text! = String("\(total2) seg.")
        }
        else {
            resultado2.text = String("Ingrese Valores Numericos")
        }
        }
    
    @IBAction func DaS(_ sender: UIButton) {
        var d = Double(Dias.text!)
        d = Double(Dias.text!)
        if( d != nil){
        var total3 = d! * 86400
        total3 = Double(d! * 86400)
        print(total3)
        resultado3.text! = String("\(total3) seg.")
        }
        else{
            resultado3.text = String("Ingrese Valores Numericos")
        }
        }
    
    
    @IBAction func semana(_ sender: UIButton) {
        var s = Double(Sem.text!)
        s = Double(Sem.text!)
        if( s != nil){
        var total4 = s! * 604800
        total4 = Double(s! * 604800)
        print(total4)
        resultado4.text! = String("\(total4) seg.")
        }
        else{
            resultado4.text = String("Ingrese Valores Numericos")
        }
        }
    

}
