//
//  CintensidadViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/26/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class CintensidadViewController: UIViewController {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    @IBOutlet weak var voltaje: UITextField!
    
    @IBOutlet weak var resistencia: UITextField!
    
    
    @IBOutlet weak var Resultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()}
    
    
    @IBAction func Intensidad(_ sender: UIButton) {
        
        var v = Double(voltaje.text!)
        v = Double(voltaje.text!)
        var r = Double(resistencia.text!)
        r = Double(resistencia.text!)
        if(v != nil && r != nil){
            var total = v!/r!
            total = Double(v!/r!)
            print(total)
            Resultado.text! = String("La Intensidad es :\(total) [A]")
            
            }
        else{Resultado.text = String("Ingrese valores numericos")
        
        }
    }
    
}
