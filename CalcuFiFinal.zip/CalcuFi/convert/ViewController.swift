//
//  ViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/12/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func fromGreyView(segue:UIStoryboardSegue!){}
    @IBAction func fromBlueView(segue:UIStoryboardSegue!){}
    @IBAction func fromPinkView(segue:UIStoryboardSegue!){}
    @IBAction func fromRedView(segue:UIStoryboardSegue!){}
    @IBAction func fromCielaView(segue:UIStoryboardSegue!){}
    
    @IBAction func fromPolloview(segue:UIStoryboardSegue!){}

    @IBAction func ohm(_ sender: UIButton) {
        
    }
    
    @IBAction func instructivo(_ sender: UIButton) {
    }
    
    @IBAction func convertidor(_ sender: UIButton) {
    }
    
    @IBAction func mru(_ sender: UIButton) {
    }
    
    @IBAction func calculadorohm(_ sender: UIButton) {
    }
    
}

