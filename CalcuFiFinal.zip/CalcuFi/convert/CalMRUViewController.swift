//
//  CalMRUViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/12/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class CalMRUViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func distancia(_ sender: UIButton) {
    }
    
    @IBAction func tiempo(_ sender: UIButton) {
    }
    
    @IBAction func velocidad(_ sender: UIButton) {
    }
    @IBAction func fromCdistanciaView(segue:UIStoryboardSegue){}
    @IBAction func fromCtiempoView(segue:UIStoryboardSegue){}
    @IBAction func fromCVelocidadView(segue:UIStoryboardSegue){}
    
    
  
}
