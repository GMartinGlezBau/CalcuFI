//
//  menuohmViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/12/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class menuohmViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func fromCieloView(segue:UIStoryboardSegue!){}
    @IBAction func fromTeoriaView(segue:UIStoryboardSegue!){}
    @IBAction func fromEjerciciosView(segue:UIStoryboardSegue!){}
    

   
}
