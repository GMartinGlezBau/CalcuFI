//
//  conveloViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/29/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class conveloViewController: UIViewController {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBOutlet weak var kms: UITextField!
    @IBOutlet weak var resultado: UILabel!
    @IBOutlet weak var boton1: UIButton!
    @IBOutlet weak var botonOk1: UIButton!
    
    @IBOutlet weak var ft: UITextField!
    @IBOutlet weak var resultado2: UILabel!
    
    @IBOutlet weak var Mh: UITextField!
    @IBOutlet weak var resultado3: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    @IBAction func botonOk1(_ sender: UIButton) {
        
        var k = Double(kms.text!)
        k = Double(kms.text!)
        if( k != nil){
        var total = k! * 0.278
        total = Double(k! * 0.278)
        print(total)
        resultado.text! = String("\(total) m/s")
        }
        else{
            resultado.text = String("Ingrese Valores Numericos")
        }
        
    }
    
    @IBAction func ftams(_ sender: UIButton) {
        var f = Double(ft.text!)
        f = Double(ft.text!)
        if( f != nil){
        var total1 = f! * 0.3048
        total1 = Double(f! * 0.3048)
        print(total1)
        resultado2.text! = String("\(total1) m/s")
        }
        else{
            resultado2.text = String("Ingrese Valores Numericos")
        }
        }
    
    @IBAction func Mhmh(_ sender: UIButton) {
        var M = Double(Mh.text!)
        M = Double(Mh.text!)
        if(M != nil){
        var total2 = M! * 0.44704
        total2 = Double(M! * 0.44704)
        print(total2)
        resultado3.text! = String("\(total2) m/s")
        }
        else{
            resultado3.text = String("Ingrese Valores Numericos")
        }
        }
    
}
