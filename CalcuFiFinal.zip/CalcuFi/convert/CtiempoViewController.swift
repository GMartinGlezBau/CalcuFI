//
//  CtiempoViewController.swift
//  convert
//
//  Created by macbook  on 11/13/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class CtiempoViewController: UIViewController {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBOutlet weak var distancia: UITextField!
    
    @IBOutlet weak var velocidad: UITextField!
    
    @IBOutlet weak var resultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func tiempo(_ sender: UIButton) {
        var d = Double(distancia.text!)
        d = Double(distancia.text!)
        var v = Double(velocidad.text!)
        v = Double(velocidad.text!)
        if( d != nil && v != nil ){
        var total = d! / v!
        total = Double(d! / v!)
        print(total)
        resultado.text! = String("El Tiempo es : \(total) [s]")
        }
        else {
            resultado.text = String("Ingrese Valores Numericos")
        }
    }
    
}

