//
//  CvelocidadViewController.swift
//  convert
//
//  Created by macbook  on 11/13/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class CvelocidadViewController: UIViewController {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBOutlet weak var distancia: UITextField!
    

    @IBOutlet weak var tiempo: UITextField!
    
    @IBOutlet weak var resultado: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func velocidad(_ sender: Any) {
        var d = Double(distancia.text!)
        d = Double(distancia.text!)
        var t = Double(tiempo.text!)
        t = Double(tiempo.text!)
        if( d != nil && t != nil){
        var total = d! / t!
        total = Double(d! / t!)
        print(total)
        resultado.text! = String("La Velocidad es :\(total) [m/s]")}
    else { resultado.text = String("Ingrese Valores Numericos")

        
    }
}
}
