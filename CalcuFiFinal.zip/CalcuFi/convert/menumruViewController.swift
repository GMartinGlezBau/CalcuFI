//
//  menumruViewController.swift
//  convert
//
//  Created by Usuario invitado on 11/12/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class menumruViewController: UIViewController {

    override func viewDidLoad() {
     super.viewDidLoad()
    }
    @IBAction func fromCmruView(segue:UIStoryboardSegue!){}
    @IBAction func fromTmruView(segue:UIStoryboardSegue!){}
    @IBAction func fromEmruView(segue:UIStoryboardSegue!){}
    

  

}
