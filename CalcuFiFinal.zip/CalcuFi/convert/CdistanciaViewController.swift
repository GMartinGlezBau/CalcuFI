//
//  CdistanciaViewController.swift
//  convert
//
//  Created by macbook  on 11/13/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class CdistanciaViewController: UIViewController {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBOutlet weak var velocidad: UITextField!
    
    @IBOutlet weak var tiempo: UITextField!
    
   
    @IBOutlet weak var resultado: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
}
    @IBAction func calcular(_ sender: UIButton) {
        var d = Double(velocidad.text!)
        d = Double(velocidad.text!)
        var t = Double(tiempo.text!)
        t = Double(tiempo.text!)
        if( d != nil && t != nil){
        var total = d! * t!
        total = Double(d! * t!)
      //  print(total)
        resultado.text! = String("La Distancia es : \(total) [m]")
        }
        else {
            resultado.text = String("Ingrese Valores Numericos")
        }
        }

}
